#include "stdio.h"
#include "string.h"

void toto(char *input){
	char buf[8];
	strcpy(buf, input);
	printf("%s", buf);
	printf("\n");
}

int main(int argc, char **argv){
	toto(argv[1]);
	return 0;
} 
